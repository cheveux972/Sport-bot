"""
config.py
=========
Configuration centrale du bot.
Modifie ce fichier avant de lancer le bot.
"""

import os
from pathlib import Path

# ─────────────────────────────────────────────
# 🔑 OBLIGATOIRE — Token Telegram
# ─────────────────────────────────────────────
# Obtiens ton token via @BotFather sur Telegram
# puis définis-le ici ou en variable d'environnement :
#   export TELEGRAM_BOT_TOKEN="1234567890:ABCDEF..."
TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "REMPLACE_PAR_TON_TOKEN")

# ─────────────────────────────────────────────
# 🔒 Accès — laisse vide pour accès public
# ─────────────────────────────────────────────
# Exemple : ALLOWED_CHAT_IDS = {123456789, 987654321}
ALLOWED_CHAT_IDS: set[int] = set()

# ─────────────────────────────────────────────
# ⏱ Intervalles de polling (secondes)
# ─────────────────────────────────────────────
WINAMAX_POLL_INTERVAL_S = 60      # Mise à jour des matchs Winamax
LIVE_UPDATE_INTERVAL_S  = 90      # Mise à jour des scores live
PREMATCH_ALERT_CHECK_S  = 300     # Vérification des alertes pré-match

# ─────────────────────────────────────────────
# 🎯 Analyse
# ─────────────────────────────────────────────
PREMATCH_WINDOW_HOURS   = 3       # Fenêtre pré-match pour /upcoming
MIN_CONFIDENCE_ALERT    = 50      # Score minimal pour alerte automatique
WINAMAX_CAPTURE_S       = 60      # Durée de capture WebSocket Winamax
MAX_LIVE_MATCHES        = 8       # Nb max de matchs live analysés en simultané

# ─────────────────────────────────────────────
# 📁 Chemins
# ─────────────────────────────────────────────
ROOT_DIR  = Path(__file__).parent
DATA_DIR  = ROOT_DIR / "data"
LOG_DIR   = ROOT_DIR / "logs"
CACHE_MAX_AGE_S = 300   # Cache Winamax invalide après 5 min

# ─────────────────────────────────────────────
# 🌐 Proxy (optionnel, si ton IP est bloquée)
# ─────────────────────────────────────────────
PROXY_URL: str | None = None
# Exemple : PROXY_URL = "http://user:pass@proxy.example.com:8080"

# ─────────────────────────────────────────────
# 📱 Telegram
# ─────────────────────────────────────────────
MAX_MESSAGE_LENGTH = 4000   # Limite Telegram (max 4096)
