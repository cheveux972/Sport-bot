# ⚽ Sport Analysis Bot — Guide d'installation

Bot Telegram qui analyse en temps réel tous les matchs Winamax :
forme récente, H2H, effectifs, score de confiance.

---

## 📋 Prérequis

- Python **3.11+**
- Un compte Telegram + un bot créé via **@BotFather**

---

## 🚀 Installation rapide

### 1. Installer les dépendances

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

### 2. Configurer le token Telegram

Ouvre `config.py` et remplace :
```python
TELEGRAM_BOT_TOKEN = "REMPLACE_PAR_TON_TOKEN"
```
par le token donné par @BotFather.

Ou via variable d'environnement (recommandé) :
```bash
export TELEGRAM_BOT_TOKEN="1234567890:ABCDEF..."
```

### 3. Lancer le bot

```bash
python bot/telegram_bot.py
```

---

## 🗂 Structure du projet

```
sport_bot/
├── config.py                   ← Configuration (token, intervalles…)
├── requirements.txt
├── scrapers/
│   ├── winamax_scraper.py      ← Matchs & cotes (WebSocket)
│   ├── sofascore_scraper.py    ← Forme, effectifs, joueurs
│   └── flashscore_scraper.py   ← Historique H2H
├── engine/
│   └── analysis_engine.py      ← Moteur d'analyse & score de confiance
├── bot/
│   └── telegram_bot.py         ← Bot Telegram principal
├── data/                       ← Cache JSON (auto-généré)
└── logs/                       ← Fichiers de log
```

---

## 📱 Commandes du bot

| Commande      | Description |
|---------------|-------------|
| `/start`      | Message de bienvenue |
| `/live`       | Matchs en cours avec score & cotes |
| `/upcoming`   | Prochains matchs (< 3h) |
| `/analyse`    | Sélectionner un match à analyser en profondeur |
| `/sport`      | Filtrer par sport (Football, Tennis, Basket…) |
| `/alertes`    | Activer/désactiver les alertes automatiques |
| `/status`     | Statut du bot et du cache |

---

## ⚙️ Options avancées (config.py)

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| `ALLOWED_CHAT_IDS` | `set()` | IDs autorisés (vide = public) |
| `WINAMAX_POLL_INTERVAL_S` | `60` | Fréquence de maj Winamax |
| `LIVE_UPDATE_INTERVAL_S` | `90` | Fréquence des updates live |
| `MIN_CONFIDENCE_ALERT` | `50` | Score min pour alerte auto |
| `PREMATCH_WINDOW_HOURS` | `3` | Fenêtre /upcoming |
| `PROXY_URL` | `None` | Proxy si IP bloquée |

---

## 🔒 Restreindre l'accès

Pour limiter le bot à certains utilisateurs, récupère ton `chat_id` :
1. Envoie `/start` à ton bot
2. Consulte `https://api.telegram.org/bot<TOKEN>/getUpdates`
3. Ajoute l'ID dans `config.py` :

```python
ALLOWED_CHAT_IDS = {123456789}
```

---

## 🛠 Dépannage

**Playwright bloqué par Winamax** → Active un proxy dans `config.py`

**SofaScore renvoie des 403** → Les headers sont déjà configurés, si ça persiste relance dans 5 min (rate limit)

**Le bot ne répond pas** → Vérifie que `TELEGRAM_BOT_TOKEN` est bien défini

**Logs** → Consultables dans `logs/bot.log`

---

## 📊 Comment fonctionne l'analyse

```
Winamax (WebSocket)
    └─ Liste des matchs + cotes live

SofaScore (API JSON)
    ├─ Forme récente (10 derniers matchs)
    ├─ Stats domicile/extérieur
    ├─ Composition officielle
    └─ Absents / blessés / suspendus

Flashscore (Playwright)
    └─ Historique H2H (confrontations directes)

Moteur d'analyse
    ├─ Score de confiance (0–100)
    │   ├─ Forme équipes (30 pts)
    │   ├─ H2H (25 pts)
    │   ├─ Effectifs (25 pts)
    │   └─ Cohérence cotes (20 pts)
    ├─ Mise conseillée (1X2 / Over / BTTS)
    ├─ Détection value bet
    └─ Rapport narratif complet
```
