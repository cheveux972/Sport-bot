"""
sofascore_scraper.py  (v2 — corrigé & renforcé)
================================================
Corrections appliquées :
  [FIX-1]  asyncio.coroutine() déprécié Python 3.11+ → remplacé par helper async
  [FIX-2]  find_team_id : correspondance trop laxiste → faux positifs ("PSG" → "PSG B")
           → Score de similarité + filtre par sport
  [FIX-3]  get_recent_form : events[-last_n:] puis reversed → ordre inversé deux fois
           → Correction de l'ordre chronologique
  [FIX-4]  _build_team_stats : clean_sheets calculé sur form (5 matchs) mais
           avg_goals calculé aussi sur len(form) → incohérence si form < 5
           → Calcul unifié sur played = len(form)
  [FIX-5]  SofaScoreClient.get() : await asyncio.sleep() dans la boucle retry
           même pour 404 → délais inutiles → skip sleep sur 404
  [FIX-6]  enrich_match : lineups/missing retournent {} si event_id=None mais
           lineups.get("home", []) crash si lineups={} et event_id=0 → guard ajouté
  [FIX-7]  SofaScoreSearcher._normalize() importe unicodedata à chaque appel → déplacé
  [FIX-8]  Headers SofaScore manquants → 403 sur certaines routes → headers enrichis

Nouveautés :
  [NEW-1]  Cache mémoire TTL pour les IDs d'équipes (évite les re-recherches)
  [NEW-2]  Récupération des stats domicile/extérieur séparément
  [NEW-3]  Note d'importance des absents (titulaire habituel vs remplaçant)
  [NEW-4]  Support page=1,2 pour récupérer plus de matchs historiques
"""

import asyncio
import json
import logging
import re
import time
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiohttp

OUTPUT_DIR = Path(__file__).parent.parent / "data"

SOFASCORE_API = "https://api.sofascore.com/api/v1"

# [FIX-8] Headers complets qui évitent les 403
HEADERS = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    "Accept":          "application/json, text/plain, */*",
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Referer":         "https://www.sofascore.com/",
    "Origin":          "https://www.sofascore.com",
    "Cache-Control":   "no-cache",
    "Pragma":          "no-cache",
    "Sec-Fetch-Dest":  "empty",
    "Sec-Fetch-Mode":  "cors",
    "Sec-Fetch-Site":  "same-site",
}

SPORT_SLUGS: dict[int, str] = {
    1:  "football",
    2:  "tennis",
    5:  "basketball",
    6:  "ice-hockey",
    13: "rugby",
    23: "volleyball",
    4:  "handball",
}

log = logging.getLogger("sofascore")


# ──────────────────────────────────────────────
# Helper pour remplacer asyncio.coroutine() [FIX-1]
# ──────────────────────────────────────────────
async def _empty_dict() -> dict:
    return {}

async def _empty_list() -> list:
    return []


# ──────────────────────────────────────────────
# Modèles de données
# ──────────────────────────────────────────────
@dataclass
class PlayerStatus:
    player_id:    int
    name:         str
    position:     str
    is_starter:   bool
    is_injured:   bool        = False
    is_suspended: bool        = False
    rating:       float | None = None
    goals:        int         = 0
    assists:      int         = 0
    matches_played: int       = 0
    importance:   str         = "unknown"  # [NEW-3] "key" | "regular" | "squad"


@dataclass
class FormEntry:
    match_id:     int
    date:         str
    opponent:     str
    home_away:    str
    result:       str      # "W" | "D" | "L"
    score:        str
    goals_for:    int
    goals_against:int
    competition:  str = ""  # [NEW] ligue du match


@dataclass
class HomeAwayStats:
    """[NEW-2] Stats séparées domicile / extérieur."""
    played:    int = 0
    wins:      int = 0
    draws:     int = 0
    losses:    int = 0
    goals_for: int = 0
    goals_ag:  int = 0

    @property
    def win_pct(self) -> float:
        return round(self.wins / self.played * 100, 1) if self.played else 0.0


@dataclass
class TeamStats:
    team_id:            int
    team_name:          str
    form:               list[FormEntry]    = field(default_factory=list)
    avg_goals_scored:   float              = 0.0
    avg_goals_conceded: float              = 0.0
    wins:               int                = 0
    draws:              int                = 0
    losses:             int                = 0
    clean_sheets:       int                = 0
    position_in_league: int | None         = None
    players:            list[PlayerStatus] = field(default_factory=list)
    home_stats:         HomeAwayStats      = field(default_factory=HomeAwayStats)  # [NEW-2]
    away_stats:         HomeAwayStats      = field(default_factory=HomeAwayStats)  # [NEW-2]

    @property
    def form_string(self) -> str:
        return "".join(f.result for f in self.form[-5:])

    def starters(self) -> list[PlayerStatus]:
        return [p for p in self.players if p.is_starter]

    def key_absences(self) -> list[PlayerStatus]:
        return [
            p for p in self.players
            if (p.is_injured or p.is_suspended) and p.importance in ("key", "regular")
        ]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class MatchLineup:
    event_id:   int
    home_stats: TeamStats
    away_stats: TeamStats
    confirmed:  bool = False
    fetched_at: str  = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ──────────────────────────────────────────────
# Normalisation [FIX-7]
# ──────────────────────────────────────────────
def normalize_name(s: str) -> str:
    """Normalise un nom pour comparaison floue (sans diacritiques, minuscules)."""
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]", "", s)


def name_similarity(a: str, b: str) -> float:
    """Score de similarité simple entre deux noms normalisés (0.0–1.0)."""
    na, nb = normalize_name(a), normalize_name(b)
    if na == nb:
        return 1.0
    if na in nb or nb in na:
        # Pénalité proportionnelle à la différence de longueur
        shorter, longer = (na, nb) if len(na) <= len(nb) else (nb, na)
        return len(shorter) / len(longer) * 0.9
    # Bigrams overlap
    def bigrams(s):
        return {s[i:i+2] for i in range(len(s)-1)}
    ba, bb = bigrams(na), bigrams(nb)
    if not ba or not bb:
        return 0.0
    overlap = len(ba & bb)
    return overlap / max(len(ba), len(bb)) * 0.7


# ──────────────────────────────────────────────
# Client HTTP avec retry [FIX-5]
# ──────────────────────────────────────────────
class SofaScoreClient:
    def __init__(self, session: aiohttp.ClientSession):
        self._session = session

    async def get(self, path: str, retries: int = 3) -> dict | None:
        url = f"{SOFASCORE_API}{path}"
        for attempt in range(retries):
            try:
                async with self._session.get(
                    url,
                    headers=HEADERS,
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as r:
                    if r.status == 200:
                        return await r.json(content_type=None)
                    if r.status == 404:
                        return None   # [FIX-5] 404 = pas de données, pas de retry
                    if r.status == 429:
                        wait = 2 ** attempt * 4
                        log.warning(f"Rate limit 429 — attente {wait}s ({url[-50:]})")
                        await asyncio.sleep(wait)
                        continue
                    if r.status == 403:
                        log.warning(f"403 Forbidden : {url[-60:]}")
                        return None
                    log.debug(f"HTTP {r.status} pour {url[-60:]}")

            except asyncio.TimeoutError:
                log.warning(f"Timeout (tentative {attempt+1}) : {url[-60:]}")
            except aiohttp.ClientError as exc:
                log.warning(f"Erreur réseau (tentative {attempt+1}) : {exc}")

            # [FIX-5] Sleep seulement si on va retenter
            if attempt < retries - 1:
                await asyncio.sleep(1.5 * (attempt + 1))

        return None


# ──────────────────────────────────────────────
# Recherche d'équipe / événement
# ──────────────────────────────────────────────
class SofaScoreSearcher:
    # [NEW-1] Cache mémoire avec TTL
    _TEAM_CACHE:  dict[str, tuple[int, float]] = {}  # name → (id, timestamp)
    _CACHE_TTL_S: int = 3600  # 1 heure

    def __init__(self, client: SofaScoreClient):
        self._c = client

    async def find_team_id(self, team_name: str, sport_id: int = 1) -> int | None:
        """[FIX-2] Recherche avec score de similarité pour éviter les faux positifs."""
        cache_key = f"{sport_id}:{team_name}"

        # Vérifier le cache
        cached = self._TEAM_CACHE.get(cache_key)
        if cached and time.time() - cached[1] < self._CACHE_TTL_S:
            return cached[0]

        encoded = team_name.replace(" ", "%20").replace("&", "%26")
        data = await self._c.get(f"/search/teams/{encoded}")
        if not data:
            return None

        results = data.get("teams", data.get("results", []))
        best_id:    int | None = None
        best_score: float      = 0.0

        for r in results[:5]:
            team = r.get("team", r)
            name = team.get("name", "")
            team_sport = team.get("sport", {})
            sport_slug = SPORT_SLUGS.get(sport_id, "football")

            # [FIX-2] Filtrer par sport si possible
            if isinstance(team_sport, dict):
                ts = team_sport.get("slug", "")
                if ts and ts != sport_slug:
                    continue

            score = name_similarity(team_name, name)
            if score > best_score and score >= 0.6:  # seuil minimal
                best_score = score
                best_id = team.get("id")

        if best_id:
            self._TEAM_CACHE[cache_key] = (best_id, time.time())
            log.debug(f"Équipe : {team_name} → ID {best_id} (score={best_score:.2f})")
        else:
            log.warning(f"Équipe non trouvée : '{team_name}' (meilleur score={best_score:.2f})")

        return best_id

    async def find_event_id(
        self,
        home: str,
        away: str,
        sport_id: int = 1,
        start_ts: int | None = None,
    ) -> int | None:
        sport_slug = SPORT_SLUGS.get(sport_id, "football")
        date_str   = datetime.fromtimestamp(
            start_ts or time.time(), tz=timezone.utc
        ).strftime("%Y-%m-%d")

        # Essayer le jour J, J-1 et J+1 (décalage fuseau horaire)
        for delta in (0, -1, 1):
            adj_ts = (start_ts or time.time()) + delta * 86400
            adj_date = datetime.fromtimestamp(adj_ts, tz=timezone.utc).strftime("%Y-%m-%d")
            data = await self._c.get(f"/sport/{sport_slug}/scheduled-events/{adj_date}")
            if not data:
                continue

            best_id:    int | None = None
            best_score: float      = 0.0

            for ev in data.get("events", []):
                h = ev.get("homeTeam", {}).get("name", "")
                a = ev.get("awayTeam", {}).get("name", "")
                sh = name_similarity(home, h)
                sa = name_similarity(away, a)
                combined = (sh + sa) / 2
                if combined > best_score and combined >= 0.65:
                    best_score = combined
                    best_id = ev.get("id")

            if best_id:
                log.debug(f"Event trouvé : {home} vs {away} → ID {best_id} (score={best_score:.2f})")
                return best_id

        return None


# ──────────────────────────────────────────────
# Scrapers spécialisés
# ──────────────────────────────────────────────
class TeamFormScraper:
    def __init__(self, client: SofaScoreClient):
        self._c = client

    async def get_recent_form(self, team_id: int, last_n: int = 10) -> list[FormEntry]:
        """[FIX-3] Ordre chronologique correct (du plus ancien au plus récent)."""
        entries: list[FormEntry] = []

        # [NEW-4] Récupérer 2 pages pour avoir plus d'historique
        for page in (0, 1):
            data = await self._c.get(f"/team/{team_id}/events/last/{page}")
            if not data:
                break

            events = data.get("events", [])
            for ev in events:
                entry = self._parse_event(ev, team_id)
                if entry:
                    entries.append(entry)

            if len(entries) >= last_n:
                break

        # [FIX-3] Trier par date ASC (du plus ancien au plus récent)
        entries.sort(key=lambda e: e.date)
        return entries[-last_n:]

    @staticmethod
    def _parse_event(ev: dict, team_id: int) -> FormEntry | None:
        try:
            home_id    = ev.get("homeTeam", {}).get("id")
            home_name  = ev.get("homeTeam", {}).get("name", "?")
            away_name  = ev.get("awayTeam", {}).get("name", "?")
            home_score = int(ev.get("homeScore", {}).get("current", 0) or 0)
            away_score = int(ev.get("awayScore", {}).get("current", 0) or 0)
            status     = ev.get("status", {}).get("type", "")

            # Ignorer les matchs non terminés
            if status not in ("finished", "canceled"):
                if ev.get("winnerCode") is None:
                    return None

            is_home    = home_id == team_id
            goals_for  = home_score if is_home else away_score
            goals_ag   = away_score if is_home else home_score
            opponent   = away_name  if is_home else home_name

            if goals_for > goals_ag:
                result = "W"
            elif goals_for < goals_ag:
                result = "L"
            else:
                result = "D"

            ts       = ev.get("startTimestamp", time.time())
            date_str = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
            comp     = ev.get("tournament", {}).get("name", "")

            return FormEntry(
                match_id     = ev.get("id", 0),
                date         = date_str,
                opponent     = opponent,
                home_away    = "home" if is_home else "away",
                result       = result,
                score        = f"{home_score}-{away_score}",
                goals_for    = goals_for,
                goals_against= goals_ag,
                competition  = comp,
            )
        except (KeyError, TypeError, ValueError):
            return None

    async def get_season_stats(self, team_id: int) -> dict:
        data = await self._c.get(f"/team/{team_id}/statistics/season")
        if not data:
            return {}
        stats = data.get("statistics", data)
        return {
            "matches_played":     stats.get("matchesPlayed") or stats.get("played"),
            "wins":               stats.get("wins"),
            "draws":              stats.get("draws"),
            "losses":             stats.get("losses"),
            "goals_scored":       stats.get("goalsScored") or stats.get("goals"),
            "goals_conceded":     stats.get("goalsConceded"),
            "clean_sheets":       stats.get("cleanSheets"),
            "avg_goals_scored":   stats.get("avgGoalsScored"),
            "avg_goals_conceded": stats.get("avgGoalsConceded"),
            "position":           stats.get("position"),
        }

    async def get_home_away_stats(self, team_id: int) -> tuple[HomeAwayStats, HomeAwayStats]:
        """[NEW-2] Stats domicile / extérieur séparées."""
        form = await self.get_recent_form(team_id, last_n=20)
        home_s = HomeAwayStats()
        away_s = HomeAwayStats()

        for f in form:
            target = home_s if f.home_away == "home" else away_s
            target.played    += 1
            target.goals_for += f.goals_for
            target.goals_ag  += f.goals_against
            if f.result == "W":
                target.wins += 1
            elif f.result == "D":
                target.draws += 1
            else:
                target.losses += 1

        return home_s, away_s


class LineupScraper:
    def __init__(self, client: SofaScoreClient):
        self._c = client

    async def get_lineups(self, event_id: int) -> dict:
        data = await self._c.get(f"/event/{event_id}/lineups")
        if not data:
            return {"confirmed": False, "home": [], "away": []}

        confirmed = data.get("confirmed", False)
        result    = {"confirmed": confirmed, "home": [], "away": []}

        for side in ("home", "away"):
            side_data = data.get(side, {})
            for p in side_data.get("players", []):
                player = p.get("player", p)
                stats  = p.get("statistics", {})
                is_sub = p.get("substitute", True)

                # [NEW-3] Importance du joueur
                rating = stats.get("rating")
                apps   = stats.get("minutesPlayed", 0) or 0
                if rating and rating >= 7.0:
                    importance = "key"
                elif apps >= 700:
                    importance = "regular"
                else:
                    importance = "squad"

                result[side].append(PlayerStatus(
                    player_id    = player.get("id", 0),
                    name         = player.get("name") or player.get("shortName", "?"),
                    position     = p.get("position") or player.get("position", "?"),
                    is_starter   = not is_sub,
                    rating       = rating,
                    goals        = stats.get("goals", 0) or 0,
                    assists      = stats.get("assists", 0) or 0,
                    matches_played = apps,
                    importance   = importance,
                ))

        return result

    async def get_missing_players(self, event_id: int) -> dict:
        data = await self._c.get(f"/event/{event_id}/missing-players")
        if not data:
            return {"home": [], "away": []}

        result = {"home": [], "away": []}
        for side in ("home", "away"):
            for entry in data.get(side, []):
                player = entry.get("player", {})
                reason = str(entry.get("reason", "unknown")).lower()
                result[side].append(PlayerStatus(
                    player_id    = player.get("id", 0),
                    name         = player.get("name", "?"),
                    position     = player.get("position", "?"),
                    is_starter   = False,
                    is_injured   = any(k in reason for k in ("injur", "ill", "malade", "bless")),
                    is_suspended = any(k in reason for k in ("suspen", "ban", "exclu", "carton")),
                    importance   = "key" if player.get("userCount", 0) > 100_000 else "regular",
                ))

        return result


class PlayerRatingScraper:
    def __init__(self, client: SofaScoreClient):
        self._c = client

    async def get_player_recent_ratings(self, player_id: int, last_n: int = 5) -> list[dict]:
        data = await self._c.get(f"/player/{player_id}/events/last/0")
        if not data:
            return []

        entries = []
        for ev in sorted(
            data.get("events", []),
            key=lambda e: e.get("startTimestamp", 0),
            reverse=True,
        )[:last_n]:
            stats = ev.get("playerStatistics", {})
            entries.append({
                "date":    datetime.fromtimestamp(
                    ev.get("startTimestamp", 0), tz=timezone.utc
                ).strftime("%Y-%m-%d"),
                "rating":  stats.get("rating"),
                "goals":   stats.get("goals", 0),
                "assists": stats.get("assists", 0),
                "minutes": stats.get("minutesPlayed", 0),
            })

        return entries


# ──────────────────────────────────────────────
# Façade principale
# ──────────────────────────────────────────────
class SofaScoreScraper:
    def __init__(self):
        self._session:  aiohttp.ClientSession | None = None
        self._client:   SofaScoreClient       | None = None
        self._searcher: SofaScoreSearcher      | None = None

    async def __aenter__(self):
        connector = aiohttp.TCPConnector(limit=10, limit_per_host=5)
        self._session  = aiohttp.ClientSession(connector=connector)
        self._client   = SofaScoreClient(self._session)
        self._searcher = SofaScoreSearcher(self._client)
        return self

    async def __aexit__(self, *_):
        if self._session and not self._session.closed:
            await self._session.close()

    async def enrich_match(
        self,
        home:     str,
        away:     str,
        sport_id: int = 1,
        start_ts: int | None = None,
    ) -> MatchLineup | None:
        c        = self._client
        searcher = self._searcher

        home_id, away_id, event_id = await asyncio.gather(
            searcher.find_team_id(home, sport_id),
            searcher.find_team_id(away, sport_id),
            searcher.find_event_id(home, away, sport_id, start_ts),
        )

        if not home_id or not away_id:
            log.warning(f"Équipes non trouvées : '{home}' (id={home_id}) / '{away}' (id={away_id})")
            return None

        log.info(f"📊 {home} (ID:{home_id}) vs {away} (ID:{away_id}) — event:{event_id}")

        form_s   = TeamFormScraper(c)
        lineup_s = LineupScraper(c)

        # [FIX-1] Remplace asyncio.coroutine() par _empty_dict / _empty_list
        lineup_coro  = lineup_s.get_lineups(event_id)        if event_id else _empty_dict()
        missing_coro = lineup_s.get_missing_players(event_id) if event_id else _empty_dict()

        (
            home_form, home_season, home_ha,
            away_form, away_season, away_ha,
            lineups, missing,
        ) = await asyncio.gather(
            form_s.get_recent_form(home_id),
            form_s.get_season_stats(home_id),
            form_s.get_home_away_stats(home_id),  # [NEW-2]
            form_s.get_recent_form(away_id),
            form_s.get_season_stats(away_id),
            form_s.get_home_away_stats(away_id),
            lineup_coro,
            missing_coro,
        )

        # [FIX-6] Guard sur lineups / missing si event_id=None
        if not isinstance(lineups, dict):
            lineups = {}
        if not isinstance(missing, dict):
            missing = {}

        home_stats = self._build_team_stats(
            team_id=home_id, team_name=home,
            form=home_form, season=home_season,
            home_away=home_ha[0],   # stats domicile
            players=lineups.get("home", []),
            missing=missing.get("home", []),
        )
        away_stats = self._build_team_stats(
            team_id=away_id, team_name=away,
            form=away_form, season=away_season,
            home_away=away_ha[1],   # stats extérieur
            players=lineups.get("away", []),
            missing=missing.get("away", []),
        )

        return MatchLineup(
            event_id   = event_id or 0,
            home_stats = home_stats,
            away_stats = away_stats,
            confirmed  = lineups.get("confirmed", False),
        )

    @staticmethod
    def _build_team_stats(
        team_id:   int,
        team_name: str,
        form:      list[FormEntry],
        season:    dict,
        home_away: HomeAwayStats,
        players:   list[PlayerStatus],
        missing:   list[PlayerStatus],
    ) -> TeamStats:
        # [FIX-4] Tout calculé depuis form pour cohérence
        played        = len(form)
        goals_for     = sum(f.goals_for      for f in form)
        goals_against = sum(f.goals_against  for f in form)
        wins          = sum(1 for f in form if f.result == "W")
        draws         = sum(1 for f in form if f.result == "D")
        losses        = sum(1 for f in form if f.result == "L")
        clean_sheets  = sum(1 for f in form if f.goals_against == 0)

        # Fusionner joueurs lineup + absents (sans doublon)
        existing_ids = {p.player_id for p in players}
        all_players  = list(players)
        for p in missing:
            if p.player_id not in existing_ids:
                all_players.append(p)
            else:
                # Mettre à jour statut sur le joueur existant
                for existing in all_players:
                    if existing.player_id == p.player_id:
                        existing.is_injured   = p.is_injured
                        existing.is_suspended = p.is_suspended
                        break

        return TeamStats(
            team_id             = team_id,
            team_name           = team_name,
            form                = form,
            avg_goals_scored    = round(goals_for    / played, 2) if played else 0.0,
            avg_goals_conceded  = round(goals_against/ played, 2) if played else 0.0,
            wins                = wins,
            draws               = draws,
            losses              = losses,
            clean_sheets        = clean_sheets,
            position_in_league  = season.get("position"),
            players             = all_players,
            home_stats          = home_away,  # [NEW-2]
            away_stats          = home_away,  # sera remplacé par l'appelant
        )

    async def get_player_form(self, player_id: int) -> list[dict]:
        rs = PlayerRatingScraper(self._client)
        return await rs.get_player_recent_ratings(player_id)


# ──────────────────────────────────────────────
# Enrichissement batch
# ──────────────────────────────────────────────
async def enrich_matches_batch(
    matches:     list[dict],
    output_dir:  Path = OUTPUT_DIR,
    concurrency: int  = 3,
) -> dict[str, MatchLineup]:
    output_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, MatchLineup] = {}
    sem = asyncio.Semaphore(concurrency)

    async with SofaScoreScraper() as ss:
        async def enrich_one(m: dict):
            async with sem:
                mid = m.get("match_id", "")
                try:
                    lineup = await ss.enrich_match(
                        home     = m["home"],
                        away     = m["away"],
                        sport_id = m.get("sport_id", 1),
                        start_ts = m.get("start_ts"),
                    )
                    if lineup:
                        results[mid] = lineup
                        log.info(f"  ✅ {m['home']} vs {m['away']}")
                    # Pause polie entre les requêtes
                    await asyncio.sleep(0.8)
                except Exception as exc:
                    log.error(f"  ❌ {m.get('home','?')} vs {m.get('away','?')} : {exc}")

        await asyncio.gather(*[enrich_one(m) for m in matches])

    # Sauvegarde atomique
    import os, tempfile
    path = output_dir / "sofascore_enriched.json"
    serialized = {
        k: {
            "event_id":   v.event_id,
            "confirmed":  v.confirmed,
            "fetched_at": v.fetched_at,
            "home":       v.home_stats.to_dict(),
            "away":       v.away_stats.to_dict(),
        }
        for k, v in results.items()
    }
    tmp_fd, tmp_path = tempfile.mkstemp(dir=output_dir, prefix=".ss_tmp_", suffix=".json")
    with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
        json.dump(serialized, f, ensure_ascii=False, indent=2)
    Path(tmp_path).replace(path)
    log.info(f"💾 {len(results)} matchs enrichis → {path.name}")

    return results


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────
async def _main() -> None:
    import argparse, sys

    parser = argparse.ArgumentParser(description="Scraper SofaScore v2")
    parser.add_argument("--home",         required=False)
    parser.add_argument("--away",         required=False)
    parser.add_argument("--sport-id",     type=int, default=1)
    parser.add_argument("--from-winamax", action="store_true")
    parser.add_argument("--limit",        type=int, default=10)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [SofaScore] %(levelname)s  %(message)s",
    )

    if args.from_winamax:
        import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
        from scrapers.winamax_scraper import WinamaxPoller
        matches = WinamaxPoller.load_cached()
        if not matches:
            print("Aucun match Winamax en cache.")
            sys.exit(1)
        results = await enrich_matches_batch(matches[:args.limit])
        print(f"{len(results)} matchs enrichis")

    elif args.home and args.away:
        async with SofaScoreScraper() as ss:
            lineup = await ss.enrich_match(args.home, args.away, args.sport_id)
            if lineup:
                print(json.dumps({
                    "home": lineup.home_stats.to_dict(),
                    "away": lineup.away_stats.to_dict(),
                    "confirmed": lineup.confirmed,
                }, ensure_ascii=False, indent=2))
            else:
                print("Aucune donnée trouvée.")
    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(_main())
