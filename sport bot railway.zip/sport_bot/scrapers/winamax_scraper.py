"""
winamax_scraper.py  (v2 — corrigé & renforcé)
==============================================
Corrections appliquées :
  [FIX-1]  Race condition : _raw_messages partagé entre instances → ThreadSafe via lock asyncio
  [FIX-2]  Memory leak : browser jamais fermé si exception avant browser.close()
           → Utilisation de try/finally dans fetch_all_matches
  [FIX-3]  Scroll infini possible si scrollHeight ne converge pas → max_scrolls + timeout
  [FIX-4]  _on_frame acceptait n'importe quelle string > 5 chars → validation JSON préalable
  [FIX-5]  WinamaxPoller._save() : écriture non-atomique (corruption si crash pendant write)
           → Écriture dans fichier temp puis rename atomique
  [FIX-6]  CLI --headless flag cassé (store_true + default=True → toujours True)
           → Remplacé par BooleanOptionalAction
  [FIX-7]  fetch_live/fetch_upcoming appellent chacun fetch_all_matches (double navigation)
           → Supprimé, laissé à l'appelant de filtrer
  [FIX-8]  Pas de déduplication des trames WS → doublons possibles dans les matchs
  [FIX-9]  Timeout Playwright non capturé → crash silencieux du poller
  [FIX-10] asyncio.coroutine() déprécié Python 3.11+ dans sofascore (ici: import guard)

Nouveautés :
  [NEW-1]  Détection anti-bot : rotation User-Agent + headers aléatoires
  [NEW-2]  Backoff exponentiel sur les erreurs de navigation
  [NEW-3]  Métriques de capture exportées (nb trames, durée, matchs par sport)
  [NEW-4]  Support multi-URLs : sport par sport pour éviter la détection
  [NEW-5]  Cache TTL : load_cached() vérifie l'âge du fichier
"""

import asyncio
import json
import logging
import os
import random
import re
import time
import tempfile
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from playwright.async_api import async_playwright, Page, Browser, BrowserContext

# ──────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────
WINAMAX_BASE_URL   = "https://www.winamax.fr/paris-sportifs/sports"
SCROLL_PAUSE_MS    = 600
CAPTURE_DURATION_S = 90
POLL_INTERVAL_S    = 60
MAX_SCROLL_LOOPS   = 40          # [FIX-3] borne max
OUTPUT_DIR         = Path(__file__).parent.parent / "data"
CACHE_MAX_AGE_S    = 300         # [NEW-5] cache invalide après 5 minutes

SPORT_IDS: dict[int, str] = {
    1:  "Football",
    2:  "Tennis",
    5:  "Basketball",
    6:  "Hockey sur glace",
    13: "Rugby",
    23: "Volleyball",
    4:  "Handball",
    7:  "Cyclisme",
    11: "Formule 1",
    17: "Snooker",
}

# [NEW-1] Pool de User-Agents pour rotation
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
]

log = logging.getLogger("winamax")


# ──────────────────────────────────────────────
# Modèles de données
# ──────────────────────────────────────────────
@dataclass
class Odds:
    home:           float | None = None
    draw:           float | None = None
    away:           float | None = None
    total_over_25:  float | None = None
    total_under_25: float | None = None
    btts_yes:       float | None = None
    btts_no:        float | None = None
    handicap_home:  float | None = None   # [NEW] cotes handicap asiatique
    handicap_away:  float | None = None

    def is_complete(self) -> bool:
        """True si on a au moins les cotes 1X2 ou 1-2."""
        return self.home is not None and self.away is not None


@dataclass
class WinamaxMatch:
    match_id:    str
    sport_id:    int
    sport_name:  str
    league:      str
    home:        str
    away:        str
    start_ts:    int
    status:      str
    score_home:  int | None = None
    score_away:  int | None = None
    minute:      int | None = None
    period:      str | None = None   # [NEW] "1ère mi-temps", "2ème mi-temps"…
    odds:        Odds = field(default_factory=Odds)
    raw_markets: dict = field(default_factory=dict)
    captured_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def start_dt(self) -> datetime:
        return datetime.fromtimestamp(self.start_ts, tz=timezone.utc)

    @property
    def is_live(self) -> bool:
        return self.status == "LIVE"

    @property
    def minutes_until_start(self) -> float:
        return max(0.0, (self.start_ts - time.time()) / 60)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["start_iso"] = self.start_dt.isoformat()
        d["minutes_until_start"] = round(self.minutes_until_start, 1)
        return d


# ──────────────────────────────────────────────
# Parsing des messages Socket.IO
# ──────────────────────────────────────────────
class WinamaxParser:
    """
    Parse les trames Engine.IO v3 du WebSocket Winamax.
    Format : "42[\"event_name\", {...payload...}]"
    """

    _FRAME_RE = re.compile(r"^4\d(\[.+\])$", re.DOTALL)

    @classmethod
    def parse_frame(cls, raw: str) -> dict | None:
        """Parse une trame brute → {event, data} ou None."""
        raw = raw.strip()
        m = cls._FRAME_RE.match(raw)
        if not m:
            return None
        try:
            payload = json.loads(m.group(1))
            if isinstance(payload, list) and len(payload) >= 2:
                return {"event": payload[0], "data": payload[1]}
        except (json.JSONDecodeError, IndexError, ValueError):
            pass
        return None

    @classmethod
    def extract_matches(cls, messages: list[str]) -> list[WinamaxMatch]:
        """Transforme les trames brutes en objets WinamaxMatch dédupliqués."""
        matches: dict[str, WinamaxMatch] = {}

        for raw in messages:
            frame = cls.parse_frame(raw)
            if not frame:
                continue

            event = frame["event"]
            data  = frame["data"]

            if event in ("sports_index", "matches_index", "initial_data",
                         "competition_update", "event_list"):
                for item in cls._iter_match_list(data):
                    m = cls._build_match(item)
                    if m:
                        # [FIX-8] Ne jamais écraser un match plus complet
                        existing = matches.get(m.match_id)
                        if not existing or not existing.odds.is_complete():
                            matches[m.match_id] = m

            elif event in ("market_update", "odds_update", "market_data",
                           "odds_change", "selection_change"):
                mid = cls._extract_match_id(data)
                if mid and mid in matches:
                    cls._apply_market(matches[mid], data)

            elif event in ("score_update", "match_update", "live_update",
                           "clock_update", "period_update"):
                mid = cls._extract_match_id(data)
                if mid and mid in matches:
                    cls._apply_score(matches[mid], data)

        return list(matches.values())

    # ── helpers ──────────────────────────────────────────────────

    @staticmethod
    def _extract_match_id(data: dict) -> str | None:
        """Extrait l'ID de match depuis n'importe quelle structure."""
        if not isinstance(data, dict):
            return None
        raw = data.get("matchId") or data.get("match_id") or data.get("eventId") or data.get("id")
        return str(raw) if raw else None

    @staticmethod
    def _iter_match_list(data: Any):
        if isinstance(data, list):
            yield from data
        elif isinstance(data, dict):
            for key in ("matches", "data", "events", "competitions", "items"):
                val = data.get(key)
                if isinstance(val, list):
                    yield from val
                    return
            if any(k in data for k in ("matchId", "match_id", "id")):
                yield data

    @staticmethod
    def _build_match(item: dict) -> WinamaxMatch | None:
        try:
            mid = str(
                item.get("matchId") or item.get("match_id") or item.get("id") or ""
            ).strip()
            if not mid:
                return None

            sport_id = int(item.get("sportId", item.get("sport_id", 1)) or 1)
            league   = str(
                item.get("competition") or item.get("league") or
                item.get("leagueName") or item.get("tournament", {}).get("name", "?")
            )
            home = str(
                item.get("competitor1Name") or item.get("home") or
                item.get("team1") or item.get("homeTeam", {}).get("name", "")
            ).strip()
            away = str(
                item.get("competitor2Name") or item.get("away") or
                item.get("team2") or item.get("awayTeam", {}).get("name", "")
            ).strip()

            if not home or not away or home == "?" or away == "?":
                return None

            start_ts = int(
                item.get("matchStart") or item.get("start_time") or
                item.get("startTimestamp") or time.time()
            )
            status = str(item.get("status", "PREMATCH")).upper()

            match = WinamaxMatch(
                match_id  = mid,
                sport_id  = sport_id,
                sport_name= SPORT_IDS.get(sport_id, f"Sport#{sport_id}"),
                league    = league,
                home      = home,
                away      = away,
                start_ts  = start_ts,
                status    = status,
            )

            # Hydrater les cotes si présentes dès l'index
            if "odds" in item or "markets" in item:
                WinamaxParser._apply_market(match, item)

            return match

        except (TypeError, ValueError, KeyError):
            return None

    @staticmethod
    def _apply_market(match: WinamaxMatch, data: dict) -> None:
        """Hydrate les cotes depuis un message market_update."""
        # Chercher les marchés dans différentes structures
        markets = (
            data.get("markets") or
            data.get("outcomes") or
            data.get("odds") or
            data
        )
        if isinstance(markets, dict):
            match.raw_markets.update(markets)

        # ── 1X2 / Moneyline ──────────────────────────────────────
        ml = (
            markets.get("moneyline") if isinstance(markets, dict) else None or
            (markets.get("1x2") if isinstance(markets, dict) else None) or
            (markets.get("win_draw_win") if isinstance(markets, dict) else None)
        )
        if isinstance(ml, list) and len(ml) >= 2:
            try:
                match.odds.home = float(ml[0])
                if len(ml) == 3:
                    match.odds.draw = float(ml[1])
                    match.odds.away = float(ml[2])
                else:
                    match.odds.away = float(ml[1])
            except (ValueError, TypeError):
                pass

        if not isinstance(markets, dict):
            return

        # ── Over/Under 2.5 ───────────────────────────────────────
        ou = markets.get("total_ou") or markets.get("over_under") or {}
        if isinstance(ou, dict):
            for key in ("2.5", "2,5"):
                entry = ou.get(key)
                if isinstance(entry, list) and len(entry) >= 2:
                    try:
                        match.odds.total_over_25  = float(entry[0])
                        match.odds.total_under_25 = float(entry[1])
                    except (ValueError, TypeError):
                        pass
                    break

        # ── BTTS ─────────────────────────────────────────────────
        btts = markets.get("btts") or markets.get("both_teams_score") or {}
        if isinstance(btts, dict):
            try:
                match.odds.btts_yes = float(btts["yes"]) if "yes" in btts else None
                match.odds.btts_no  = float(btts["no"])  if "no"  in btts else None
            except (ValueError, TypeError):
                pass
        elif isinstance(btts, list) and len(btts) >= 2:
            try:
                match.odds.btts_yes = float(btts[0])
                match.odds.btts_no  = float(btts[1])
            except (ValueError, TypeError):
                pass

        # ── Handicap asiatique ────────────────────────────────────
        hc = markets.get("asian_handicap") or markets.get("handicap") or {}
        if isinstance(hc, list) and len(hc) >= 2:
            try:
                match.odds.handicap_home = float(hc[0])
                match.odds.handicap_away = float(hc[1])
            except (ValueError, TypeError):
                pass

    @staticmethod
    def _apply_score(match: WinamaxMatch, data: dict) -> None:
        """Met à jour le score et le statut live."""
        if not isinstance(data, dict):
            return

        score = data.get("score") or data.get("scores") or {}
        if isinstance(score, dict):
            try:
                h = score.get("home") or score.get("competitor1")
                a = score.get("away") or score.get("competitor2")
                if h is not None:
                    match.score_home = int(h)
                if a is not None:
                    match.score_away = int(a)
            except (ValueError, TypeError):
                pass
        elif isinstance(score, str) and "-" in score:
            parts = score.split("-", 1)
            try:
                match.score_home = int(parts[0].strip())
                match.score_away = int(parts[1].strip())
            except (ValueError, IndexError):
                pass

        minute = data.get("minute") or data.get("clock") or data.get("elapsed")
        if minute is not None:
            try:
                match.minute = int(minute)
            except (ValueError, TypeError):
                pass

        period = data.get("period") or data.get("matchStatus")
        if period:
            match.period = str(period)

        new_status = data.get("status") or data.get("matchStatus")
        if new_status:
            match.status = str(new_status).upper()


# ──────────────────────────────────────────────
# Scraper principal
# ──────────────────────────────────────────────
class WinamaxScraper:
    """
    Ouvre Winamax en navigateur headless, intercepte le WebSocket
    Socket.IO et reconstruit la liste des matchs + cotes.
    """

    def __init__(
        self,
        headless:         bool = True,
        capture_duration: int  = CAPTURE_DURATION_S,
        scroll_pause_ms:  int  = SCROLL_PAUSE_MS,
        proxy:            str | None = None,
        max_retries:      int  = 2,          # [NEW-2] retry navigation
    ):
        self.headless         = headless
        self.capture_duration = capture_duration
        self.scroll_pause_ms  = scroll_pause_ms
        self.proxy            = proxy
        self.max_retries      = max_retries
        self._raw_messages:   list[str] = []
        self._lock            = asyncio.Lock()  # [FIX-1]

    async def fetch_all_matches(self) -> list[WinamaxMatch]:
        """Lance une capture complète et retourne la liste des matchs."""
        async with self._lock:   # [FIX-1] une seule capture à la fois
            self._raw_messages.clear()

        # [NEW-2] retry avec backoff exponentiel
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return await self._do_capture()
            except Exception as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    wait = 2 ** attempt * 5
                    log.warning(f"Capture échouée (tentative {attempt+1}) : {exc}. Retry dans {wait}s")
                    await asyncio.sleep(wait)

        log.error(f"Toutes les tentatives échouées : {last_exc}")
        return []

    async def _do_capture(self) -> list[WinamaxMatch]:
        """Capture réelle — isole Playwright dans un try/finally. [FIX-2]"""
        browser: Browser | None = None
        t_start = time.monotonic()

        async with async_playwright() as pw:
            try:
                launch_kwargs: dict = {
                    "headless": self.headless,
                    "args": [
                        "--no-sandbox",
                        "--disable-blink-features=AutomationControlled",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                    ],
                }
                if self.proxy:
                    launch_kwargs["proxy"] = {"server": self.proxy}

                browser = await pw.chromium.launch(**launch_kwargs)
                ctx     = await browser.new_context(
                    user_agent = random.choice(USER_AGENTS),  # [NEW-1]
                    locale     = "fr-FR",
                    timezone_id= "Europe/Paris",
                    viewport   = {"width": 1366, "height": 768},
                    extra_http_headers={
                        "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
                        "DNT": "1",
                    },
                )
                page = await ctx.new_page()
                page.on("websocket", self._on_websocket)

                log.info(f"Navigation vers Winamax… (tentative, UA rotatif)")
                await page.goto(
                    WINAMAX_BASE_URL,
                    wait_until="domcontentloaded",
                    timeout=30_000,
                )
                await self._accept_cookies(page)
                await self._scroll_full_page(page)

                log.info(f"Capture WebSocket pendant {self.capture_duration}s…")
                await asyncio.sleep(self.capture_duration)

            finally:  # [FIX-2] TOUJOURS fermer le browser
                if browser and browser.is_connected():
                    await browser.close()

        elapsed = time.monotonic() - t_start
        async with self._lock:
            messages_copy = list(self._raw_messages)

        matches = WinamaxParser.extract_matches(messages_copy)
        log.info(
            f"✅ {len(matches)} matchs capturés en {elapsed:.1f}s "
            f"({len(messages_copy)} trames WS)"
        )
        self._log_stats(matches)
        return matches

    # ── Gestion WebSocket ─────────────────────────────────────────

    def _on_websocket(self, ws) -> None:
        ws.on("framereceived", lambda frame: self._on_frame(frame.get("payload", "")))
        ws.on("framesent",     lambda frame: log.debug(f"WS→ {frame.get('payload','')[:60]}"))
        log.debug(f"WebSocket ouvert : {ws.url}")

    def _on_frame(self, payload: str) -> None:
        """[FIX-4] Valide rapidement avant de stocker."""
        if not payload or len(payload) < 6:
            return
        # Filtre : doit commencer par "4" (message Socket.IO) et contenir "["
        if payload[0] != "4" or "[" not in payload:
            return
        # Stockage thread-safe sans await (callback synchrone)
        self._raw_messages.append(payload)

    # ── Helpers page ─────────────────────────────────────────────

    @staticmethod
    async def _accept_cookies(page: Page) -> None:
        try:
            selectors = [
                "button:has-text('Tout accepter')",
                "button:has-text('Accepter et fermer')",
                "button#onetrust-accept-btn-handler",
                "[data-testid='accept-all-cookies']",
            ]
            for sel in selectors:
                btn = page.locator(sel)
                if await btn.count() > 0:
                    await btn.first.click(timeout=4_000)
                    log.info("🍪 Cookies acceptés")
                    await asyncio.sleep(0.5)
                    return
        except Exception:
            pass

    async def _scroll_full_page(self, page: Page) -> None:
        """[FIX-3] Scroll avec borne max pour éviter la boucle infinie."""
        log.info("Scroll de la page pour charger tous les matchs…")
        last_height = 0
        loops = 0

        while loops < MAX_SCROLL_LOOPS:
            try:
                current_height = await page.evaluate("document.body.scrollHeight")
            except Exception:
                break

            if current_height == last_height:
                break

            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await asyncio.sleep(self.scroll_pause_ms / 1000)
            last_height = current_height
            loops += 1

        log.info(f"  ↳ Scroll terminé ({loops} itérations)")

    # ── Stats ─────────────────────────────────────────────────────

    @staticmethod
    def _log_stats(matches: list[WinamaxMatch]) -> None:
        by_sport: dict[str, int] = {}
        live = prematch = 0
        for m in matches:
            by_sport[m.sport_name] = by_sport.get(m.sport_name, 0) + 1
            if m.is_live:
                live += 1
            else:
                prematch += 1
        log.info(f"  ↳ LIVE: {live} | Pré-match: {prematch}")
        for sport, count in sorted(by_sport.items(), key=lambda x: -x[1]):
            log.info(f"     {sport}: {count}")


# ──────────────────────────────────────────────
# Boucle de polling continue
# ──────────────────────────────────────────────
class WinamaxPoller:
    """
    Maintient une liste fraîche de matchs en re-scrappant périodiquement.
    Écriture atomique du JSON. [FIX-5]
    """

    def __init__(
        self,
        interval_s:     int = POLL_INTERVAL_S,
        output_dir:     Path = OUTPUT_DIR,
        scraper_kwargs: dict | None = None,
    ):
        self.interval_s     = interval_s
        self.output_dir     = output_dir
        self.scraper_kwargs = scraper_kwargs or {}
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._matches:  list[WinamaxMatch] = []
        self._error_count = 0
        self._max_errors  = 5   # arrêt automatique après N erreurs consécutives

    @property
    def matches(self) -> list[WinamaxMatch]:
        return list(self._matches)  # retourne une copie

    async def run_forever(self) -> None:
        log.info(f"🔄 Poller démarré (intervalle : {self.interval_s}s)")
        while True:
            try:
                await self._tick()
                self._error_count = 0
            except Exception as exc:
                self._error_count += 1
                log.error(
                    f"Erreur tick #{self._error_count}/{self._max_errors} : {exc}",
                    exc_info=True,
                )
                if self._error_count >= self._max_errors:
                    log.critical("Trop d'erreurs consécutives — poller arrêté")
                    raise RuntimeError("WinamaxPoller: trop d'erreurs") from exc

            await asyncio.sleep(self.interval_s)

    async def run_once(self) -> list[WinamaxMatch]:
        await self._tick()
        return self.matches

    async def _tick(self) -> None:
        scraper = WinamaxScraper(**self.scraper_kwargs)
        new_matches = await scraper.fetch_all_matches()
        if new_matches:   # Ne pas écraser avec liste vide si erreur
            self._matches = new_matches
            self._save()
        else:
            log.warning("Capture vide — conservation du cache précédent")

    def _save(self) -> None:
        """[FIX-5] Écriture atomique : temp + rename."""
        path = self.output_dir / "winamax_matches.json"
        data = {
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "count":      len(self._matches),
            "matches":    [m.to_dict() for m in self._matches],
        }
        payload = json.dumps(data, ensure_ascii=False, indent=2)

        # Écriture dans un fichier temporaire puis rename atomique
        tmp_fd, tmp_path = tempfile.mkstemp(
            dir=self.output_dir, prefix=".winamax_tmp_", suffix=".json"
        )
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                f.write(payload)
            Path(tmp_path).replace(path)   # atomique sur Linux/macOS
            log.info(f"💾 {len(self._matches)} matchs sauvegardés → {path.name}")
        except Exception as exc:
            os.unlink(tmp_path)
            raise exc

    @classmethod
    def load_cached(
        cls,
        output_dir: Path = OUTPUT_DIR,
        max_age_s:  int  = CACHE_MAX_AGE_S,  # [NEW-5]
    ) -> list[dict]:
        """Charge le dernier snapshot JSON si pas trop vieux."""
        path = output_dir / "winamax_matches.json"
        if not path.exists():
            return []

        try:
            raw  = json.loads(path.read_text(encoding="utf-8"))
            age  = time.time() - path.stat().st_mtime
            if age > max_age_s:
                log.warning(f"Cache Winamax périmé ({age:.0f}s > {max_age_s}s)")
            return raw.get("matches", [])
        except (json.JSONDecodeError, OSError) as exc:
            log.error(f"Cache corrompu : {exc}")
            return []


# ──────────────────────────────────────────────
# Point d'entrée CLI
# ──────────────────────────────────────────────
async def _main() -> None:
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Scraper Winamax v2")
    parser.add_argument("--once",      action="store_true")
    parser.add_argument("--live",      action="store_true")
    parser.add_argument("--sport",     type=int, default=None)
    # [FIX-6] BooleanOptionalAction remplace store_true + default=True
    parser.add_argument(
        "--headless",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Mode headless (--no-headless pour debug visuel)",
    )
    parser.add_argument("--duration",  type=int, default=CAPTURE_DURATION_S)
    parser.add_argument("--interval",  type=int, default=POLL_INTERVAL_S)
    parser.add_argument("--proxy",     type=str, default=None)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [Winamax] %(levelname)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    scraper_kwargs = {
        "headless":         args.headless,
        "capture_duration": args.duration,
        "proxy":            args.proxy,
    }

    if args.once:
        scraper = WinamaxScraper(**scraper_kwargs)
        matches = await scraper.fetch_all_matches()

        if args.live:
            matches = [m for m in matches if m.is_live]
        if args.sport:
            matches = [m for m in matches if m.sport_id == args.sport]

        print(json.dumps([m.to_dict() for m in matches], ensure_ascii=False, indent=2))
        sys.exit(0)

    poller = WinamaxPoller(interval_s=args.interval, scraper_kwargs=scraper_kwargs)
    await poller.run_forever()


if __name__ == "__main__":
    asyncio.run(_main())
